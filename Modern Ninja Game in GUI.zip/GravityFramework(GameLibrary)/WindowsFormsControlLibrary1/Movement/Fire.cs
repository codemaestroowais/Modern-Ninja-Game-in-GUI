﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsControlLibrary1.Core;
using System.Windows.Forms;
using System.Drawing;

namespace WindowsFormsControlLibrary1.Movement
{
    public class Fire:IMovement
    {
        private int Speed;
        private Point Boundary;
        private Direction Direction;

        public Fire(int speed, Point boundary, Direction direction)
        {
            this.Speed = speed;
            this.Boundary = boundary;
            this.Direction = direction;
        }

        public Point move(Point location)
        {
            if (Direction == Direction.left)
            {
                location.X -= Speed;
            }
            else if (Direction == Direction.right)
                location.X += Speed;
            return location;
        }
    }
}
