﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using WindowsFormsControlLibrary1.Core;

namespace WindowsFormsControlLibrary1.Movement
{
    public class Horiziontal:IMovement
    {
        private int speed;
        private Point boundary;
        private int offSet;
        private Direction direction;
        public Horiziontal(int speed,Point boundary,Direction direction) 
        {
            this.speed = speed;
            this.boundary = boundary;
            this.direction = direction;
            offSet = 160;
        }
        public Point move(Point loctaion)
        {
            if(loctaion.X<=0)
            {
                direction = Direction.right;
            }
            else if(loctaion.X + offSet >= boundary.X)
            {
                direction=Direction.left;
            }
            if(direction==Direction.left)
            {
                loctaion.X -= speed;
            }
            else if(direction==Direction.right)
            {
                loctaion.X += speed;
            }
            return loctaion;
        }
    }
}
