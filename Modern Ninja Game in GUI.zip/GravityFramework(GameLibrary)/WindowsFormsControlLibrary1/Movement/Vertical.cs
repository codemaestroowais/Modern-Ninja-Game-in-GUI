﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsControlLibrary1.Core;

namespace WindowsFormsControlLibrary1.Movement
{
    public class Vertical:IMovement
    {
        private int speed;
        private Point boundary;
        private Direction direction;
        private int offSet;
        public Vertical(int speed,Point boundary,Direction direction) 
        {
            this.speed = speed;
            this.boundary = boundary;
            this.direction = direction;
            this.offSet = 160;
        }
        public Point move(Point loctaion)
        {
            if (loctaion.Y <= 0)
            {
                direction = Direction.down;
            }
            else if (loctaion.Y+offSet  >= boundary.Y)
            {
                direction = Direction.up;
            }
            if (direction == Direction.down)

            {
                loctaion.Y += speed;
            }
            else if (direction == Direction.up)
            {
                loctaion.Y -= speed;
            }
            return loctaion;
        }
    }
}
