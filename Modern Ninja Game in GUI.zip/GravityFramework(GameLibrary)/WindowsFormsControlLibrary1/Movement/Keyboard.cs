﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EZInput;
namespace WindowsFormsControlLibrary1.Movement
{
    public class Keyboard : IMovement
    {

        private int speed;
        private System.Drawing.Point boundary;
        private int offSet;

        public Keyboard(int speed, System.Drawing.Point boundary)
        {
            this.speed = speed;
            this.boundary = boundary;
            offSet = 160;
         
        }
        //public void keyPressedByUser(Keys keyCode)
        //{
        //    if(keyCode == Keys.Up) 
        //    {
        //        arrowAction = "up";
        //    }
        //   else if (keyCode == Keys.Down)
        //    {
        //        arrowAction = "down";
        //    }
        //    else if (keyCode == Keys.Right)
        //    {
        //        arrowAction = "right";
        //    }
        //    else if (keyCode == Keys.Left)
        //    {
        //        arrowAction = "left";
        //    }
        //}
        //public Point move(Point location)
        //{
        //    if (arrowAction != null)
        //    {
        //        if (arrowAction == "up")
        //        {
        //            location.Y -= speed;
        //        }

        //        if (arrowAction == "down")
        //        {
        //            location.Y += speed;
        //        }

        //        if (arrowAction == "left")
        //        {
        //            location.X -= speed;
        //        }
        //        if (arrowAction == "right")
        //        {
        //            location.X += speed;
        //        }
        //        arrowAction = null;
        //    }
        //    return location;
        //}
        public System.Drawing.Point move(System.Drawing.Point location)
        {
            if (EZInput.Keyboard.IsKeyPressed(Key.UpArrow))
            {
                if (location.Y + speed > 10)
                {
                    location.Y -= speed;
                }
            }
            if (EZInput.Keyboard.IsKeyPressed(Key.DownArrow))
            {
                if (location.Y + offSet < boundary.Y)
                {
                    location.Y += speed;
                }
            }
            if (EZInput.Keyboard.IsKeyPressed(Key.LeftArrow))
            {
                if (location.X + speed > 10)
                {
                    location.X -= speed;
                }
            }
            if (EZInput.Keyboard.IsKeyPressed(Key.RightArrow))
            {
                if (location.X + offSet < boundary.X)
                {
                    location.X += speed;

                }
            }
            return location;
        }
    }
}
