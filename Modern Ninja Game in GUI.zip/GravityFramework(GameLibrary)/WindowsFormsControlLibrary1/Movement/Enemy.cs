﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace WindowsFormsControlLibrary1.Movement
{
    public class Enemy : IMovement
    {
        public Point move(Point location)
        {
            return location;
        }
    }
}
