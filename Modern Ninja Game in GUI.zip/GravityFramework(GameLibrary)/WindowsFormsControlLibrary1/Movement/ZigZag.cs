﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsControlLibrary1.Core;

namespace WindowsFormsControlLibrary1.Movement
{
    public  class ZigZag:IMovement
    {
        private int speed;
        private Point boundary;
        private Direction direction;
        private int offSet;
        private int Count;
        public ZigZag(int speed, Point boundary, Direction direction)
        {
            this.speed = speed;
            this.boundary = boundary;
            this.direction = direction;
            this.Count = 0;
        }
        public Point move(Point location)
        {
            if (direction == Direction.right)
            {
                if (Count < 5)
                {
                    location.X += speed;
                    location.Y -= speed;
                }
                else if (Count >= 5 && Count < 10)
                {
                    location.X += speed;
                    location.Y += speed;
                }
            }
            else if (direction == Direction.left)
            {
                if (Count < 5)
                {
                    location.X -= speed;
                    location.Y += speed;
                }
                else if (Count >= 5 && Count < 10)
                {
                    location.X -= speed;
                    location.Y -= speed;
                }

            }
            if ((location.X + offSet) >= boundary.X)
            {
                direction = Direction.left;
            }
            else if (location.X + speed <= 0)
            {
                direction = Direction.right;
            }
            if (Count == 10)
            {
                Count = 0;
            }
            Count++;
            return location;
        }
    }
}
