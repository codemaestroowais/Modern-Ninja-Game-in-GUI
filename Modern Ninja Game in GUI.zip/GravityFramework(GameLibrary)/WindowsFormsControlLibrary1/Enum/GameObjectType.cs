﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsControlLibrary1.Core
{
    public enum GameObjectType
    {
        Player,
        Enemy,
        planet,
        Reward,
        spaceShip,
        asteroid,
        Door
    }
}
