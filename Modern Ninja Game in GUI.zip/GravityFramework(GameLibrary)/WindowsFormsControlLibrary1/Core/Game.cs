﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using Framework.Core;
using System.Windows.Forms;
using WindowsFormsControlLibrary1.Movement;

namespace WindowsFormsControlLibrary1.Core
{
    public class Game
    {
        private static List<GameObject> AllObjects;
        private List<CollisionDetection> CollisionDetections;
        private int gravity;
        private Form container;
        private static Game instance;
        private int Points;
        
        private Game(int gravity,Form con)
        {
            this.gravity = gravity;
            AllObjects = new List<GameObject>();
            container = con;
            CollisionDetections = new List<CollisionDetection>();
            Points = 1;
        }
        public Game()
        {
           
        }
        public static Game GetInstance(int gravity, Form con)
        {
         
            if (instance == null)
            {
                instance = new Game(gravity,con);
            }
           
            return instance;
        }
        public static List<GameObject> GetGameObjects() 
        {
            return AllObjects;
        }

        public void Update(Game g)
        {
             outerLoop:
            foreach (GameObject gameObject in AllObjects)
            {
                gameObject.Update();
            }
           
            foreach (GameObject gameObject in AllObjects)
            {
                if(gameObject.Type==GameObjectType.Player)
                {
                    foreach (GameObject gameObject2 in AllObjects)
                    {
                        if (gameObject2.Type!=GameObjectType.Player)
                        {
                           
                            foreach (CollisionDetection detect in CollisionDetections)
                            {
                                if(detect.getObject1()==gameObject.Type&&detect.getObject2()==gameObject2.Type) 
                                {
                                   if( CollisionDetection.DetectCollision(gameObject, gameObject2, detect.getAction(), g))
                                    {
                                        goto outerLoop; 
                                    }
                                }
                               
                            }
                           
                        }
                    }
                }
            }
        }
        public void AddGameObject(Image img, int Top, int Left, GameObjectType Type, IMovement movement)
        {
            GameObject go = new GameObject(img, Top, Left, movement, Type);
            AllObjects.Add(go);
            container.Controls.Add(go.Pb);
        }
        public void AddGameObject(Image img, int Top, int Left, GameObjectType Type)
        {
            GameObject gameObject = new GameObject(img, Top, Left, Type);
            AllObjects.Add(gameObject);
            container.Controls.Add(gameObject.Pb);
        }
        public void AddCollision(CollisionDetection cd)
        {
            CollisionDetections.Add(cd);
        }
        public int GetPoints() 
        { 
            return Points;
        }
        public void IncreasePoints(int points) 
        {  
            this.Points += points; 
        }
        public void DecreasePoints(int points)
        {
            this.Points -= points;
        }
        public PictureBox GetPlayerPictureBox()
        {
            foreach(GameObject gameObject  in AllObjects)
            {
                if(gameObject.Type == GameObjectType.Player)
                {
                    return gameObject.Pb;
                }
            }
            return null;
        }
        //public static void DisplayTotalEnemies()
        //{
        //    lbl1 = new Label();
        //    lbl1.Location = new Point(10, 10);
        //    lbl1.AutoSize = true;
        //    int totalEnemies = GameObject.GetTotalObjects(ObjectType.enemy);
        //    lbl1.Text = "Total Enemies: " + totalEnemies;
        //}
        //public static void DisplayTotalPlayer()
        //{
        //     lbl2 = new Label();
        //    lbl2.Location = new Point(10, 14);
        //    lbl2.AutoSize = true;
        //    int totalPlayer = GameObject.GetTotalObjects(ObjectType.enemy);
        //    lbl2.Text = "Total Players: " + totalPlayer;
        //}
        //public static void DisplayTotalPlanet()
        //{
        //     lbl3 = new Label();
        //    lbl3.Location = new Point(10, 18);
        //    lbl3.AutoSize = true;
        //    int totalPlanet = GameObject.GetTotalObjects(ObjectType.enemy);
        //    lbl3.Text = "Total Planets: " + totalPlanet;
        //}
        //public static void DisplayTotalAsteroid()
        //{
        //     lbl4 = new Label();
        //    lbl4.Location = new Point(10, 22);
        //    lbl4.AutoSize = true;
        //    int totalAsteriod = GameObject.GetTotalObjects(ObjectType.enemy);
        //    lbl4.Text = "Total Asteriods: " + totalAsteriod;
        //}
    }
}
