﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using WindowsFormsControlLibrary1.Movement;
using WindowsFormsControlLibrary1.Core;

namespace Framework.Core
{
    public class GameObject
    {
        
        private PictureBox pb;
        private IMovement movement;
        public GameObjectType Type;
        private Rectangle bounds;
        private static List<int> totalObjects = new List<int>(new int[Enum.GetValues(typeof(GameObjectType)).Length]);
        public GameObject(Image img,int Top,int Left,IMovement movement,GameObjectType type)
        {
            Pb = new PictureBox();
            Pb.Image = img;
            Pb.Width = img.Width;
            Pb.Height = img.Height;
            pb.Top = Top;
            pb.Left = Left;
            pb.SizeMode = PictureBoxSizeMode.StretchImage;
            Pb.BackColor = Color.Transparent;
            this.movement= movement;
            this.Type = type;
            AddObject();
        }
        public GameObject(Image img, int Top, int Left, GameObjectType type)
        {
            Pb = new PictureBox();
            Pb.Image = img;
            Pb.Width = img.Width;
            Pb.Height = img.Height;
            pb.Top = Top;
            pb.Left = Left;
            pb.SizeMode = PictureBoxSizeMode.StretchImage;
            Pb.BackColor = Color.Transparent;
            movement = null;
            this.Type = type;
            AddObject();
        }
        public static List<int> GetObjects()
        {
            return totalObjects;
        }
        public PictureBox Pb { get => pb; set => pb = value; }
        public IMovement Movement { get => movement; set => movement = value; }

        public void Update()
        {
            if (this.movement != null)
            {
                pb.Location = movement.move(pb.Location);
            }
            
        }
        private void AddObject()
        {
            totalObjects[(int)Type]++;
        }

        //public void RemoveObject()
        //{
        //    totalObjects[(int)Type]--;
        //}
        public static void RemoveObject(GameObjectType type)
        {
            totalObjects[(int)type]--;
        }
        public static int GetTotalObjects(GameObjectType type)
        {
            return totalObjects[(int)type];
        }
        public GameObjectType GetGameObjectType()
        {
            return Type;
        }

    }
}
