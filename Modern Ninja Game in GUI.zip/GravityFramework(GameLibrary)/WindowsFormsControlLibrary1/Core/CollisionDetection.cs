﻿using Framework.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.CompilerServices;
namespace WindowsFormsControlLibrary1.Core
{
    public class CollisionDetection
    {
        private GameObjectType object1;
        private GameObjectType object2;
        private GameAction action;
        private static Form Con;
        public CollisionDetection(GameObjectType object1, GameObjectType object2, GameAction action,Form con)
        {
            this.object1 = object1;
            this.object2 = object2;
            this.action = action;
            Con = con;
        }
        public GameObjectType getObject1() 
        {
            return object1;
        }
        public GameObjectType getObject2() 
        {
            return object2;
        }
        public GameAction getAction() 
        {
            return action;
        }
        public static  bool DetectCollision(GameObject ob1,GameObject ob2,GameAction act,Game g)
        {
            if (ob1.Pb.Bounds.IntersectsWith(ob2.Pb.Bounds))
            {
                if (act == GameAction.IncreasePoints)
                {
                    Con.Controls.Remove(ob2.Pb);
                    GameObject.RemoveObject(ob2.GetGameObjectType());
                    Game.GetGameObjects().Remove(ob2);
                    g.IncreasePoints(1);
                    return true;
                }
                else if (act == GameAction.Decreasepoints)
                {
                    
                    g.DecreasePoints(1);
                }
                else if (act == GameAction.BonusPoints)
                {

                    Con.Controls.Remove(ob2.Pb);
                    g.IncreasePoints(100);
                }
                else if (act==GameAction.GameOver)
                {
                    Con.Close();
                }
                else
                {
                    MessageBox.Show("No Action");
                }
            }
            else
            {
                Console.WriteLine("No Collision Detected.");
            }
            return false;
        }
    }
}
