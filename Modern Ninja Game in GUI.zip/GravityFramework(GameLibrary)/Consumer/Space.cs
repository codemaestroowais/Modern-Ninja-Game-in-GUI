﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Framework.Core;
using WindowsFormsControlLibrary1.Core;
using WindowsFormsControlLibrary1.Movement;

namespace Consumer
{
    public partial class Space : Form
    {
        Game game;
        public Space()
        {
            InitializeComponent();
        }

        private void Space_Load(object sender, EventArgs e)
        {
            //game = new Game(10,this);
          

            //Point boundary= new Point(this.Width,this.Height);
            //game.AddGameObject(Consumer.Properties.Resources.Enemy_1_A_Small, 20, 20,new Keyboard(10,boundary));
            //game.AddGameObject(Consumer.Properties.Resources.Shop_Cristal_Icon_01, 20, 250,new Horiziontal(3, boundary, "left"));
            //game.AddGameObject(Consumer.Properties.Resources._6, 20, 150,new Vertical(3,boundary,"down"));
        }

       

        private void gameLoop_Tick(object sender, EventArgs e)
        {
            game.Update();
        }

        private void Space_KeyDown(object sender, KeyEventArgs e)
        {
          
        }
    }
}
