﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameForms.Properties;
using WindowsFormsControlLibrary1.Core;
using WindowsFormsControlLibrary1.Movement;
namespace GameForms
{
    public partial class GamePlay : Form
    {
        private Label Points;
        public GamePlay()
        {
            InitializeComponent();
            iinit();
        }
        public void iinit()
        {
            Points = new Label();
            Points.Text = "Points: ";
            Points.Location = new System.Drawing.Point(10, 50);
            Points.AutoSize = true;
            Points.Font = new Font("Arial", 14, FontStyle.Bold);
            Points.ForeColor = Color.White;
            Points.BackColor = Color.DarkBlue;
            Points.BorderStyle = BorderStyle.FixedSingle;
            this.Controls.Add(Points);
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        Game game;

        private void GamePlay_Load(object sender, EventArgs e)
        {
            game = Game.GetInstance(5,this);
            Point boundry = new Point(this.Width, this.Height+90);
            //for enemy mving vertically
            game.AddGameObject(Resources.Enemy3, 10, 1110, GameObjectType.Enemy, new Vertical(8, boundry, Direction.down));
            //for enemy on track path
            game.AddGameObject(Resources.Enemy3, 77, 530, GameObjectType.Enemy);
            game.AddGameObject(Resources.Enemy3, 265, 355, GameObjectType.Enemy);
            game.AddGameObject(Resources.Enemy3, 390, 750 ,GameObjectType.Enemy);
            //for gate
            game.AddGameObject(Resources.Gate2, 470, 1210, GameObjectType.Door);
            //for player
            game.AddGameObject(Resources.PlayerFinal1, 470, 5, GameObjectType.Player, new Keyboard(8, boundry));
            //for zigzag movement of the enemy`
            //game.addGameObject(Resources.Enemy3, 1170, 50, new ZigZagMovement(8, boundry, "right"));
            //for the horizontal movement of the enemy
            //game.addGameObject(Resources.Enemy3, 1170, 10, new HorizontalPatrol(8, boundry, "left"));
            //this is for the bar track bar of the enemy 
            //game.addGameObject(Resources.Bar1, 10, 10, new VerticalPatrol(8, boundry, "down"));
            CollisionDetection cd1 = new CollisionDetection(GameObjectType.Player, GameObjectType.Enemy, GameAction.IncreasePoints,this);
            CollisionDetection collisionDetection = new CollisionDetection(GameObjectType.Player,GameObjectType.Door, GameAction.GameOver,this);  
            game.AddCollision(cd1);
            game.AddCollision(collisionDetection);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            int points = game.GetPoints();
            Points.Text = "Points: " + points;

            game.Update(game);
           
            
         
        }
        private void DetectDoorColllison()
        {
            PictureBox pictureBox = game.GetPlayerPictureBox();

        }
    }
}
