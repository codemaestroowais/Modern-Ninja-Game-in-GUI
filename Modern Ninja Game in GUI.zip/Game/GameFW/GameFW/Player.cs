﻿using GameFW;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameFW
{
    public class Player : GameObject, IPlayer
    {
        public Player(Image image, int top, int left, IMovement controller, ObjectTyoe gameObjectType) : base(image, top, left, controller, gameObjectType)
        {
        }

        public void Fire()
        {
            throw new NotImplementedException();
        }
    }
}
