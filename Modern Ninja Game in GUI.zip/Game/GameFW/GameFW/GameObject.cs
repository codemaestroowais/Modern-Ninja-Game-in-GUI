﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameFW
{
    public class GameObject
    {
        PictureBox pb;
        IMovement controller;
        public ObjectTyoe objectTyoe;

        public GameObject(Image img, int left, int top, IMovement controller, ObjectTyoe objectTyoe)
        {
            pb = new PictureBox();
            pb.Image = img;
            pb.Width = img.Width;
            pb.Height = img.Height;
            pb.BackColor = Color.Transparent;
            pb.Left = left;
            pb.Top = top;
            this.controller = controller;
            this.objectTyoe = objectTyoe;
        }
        public void SetPictureBox(PictureBox pb)
        {
            this.pb = pb;
        }
        public PictureBox GetPictureBox() { return pb; }
        
        public void update()
        {
            this.pb.Location = controller.move(this.pb.Location);    
        }
    }
}
