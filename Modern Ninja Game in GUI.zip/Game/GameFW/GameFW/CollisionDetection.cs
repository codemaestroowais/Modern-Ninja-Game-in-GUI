﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameFW
{
    public class CollisionDetection
    {
        public ObjectTyoe GameObjectTyoe1;
        public ObjectTyoe GameObjectTyoe2;
        public ActionOnCollision ActionOnCollision;
        static IChangeDirection changeDirection = new ChangeDirection();

        public CollisionDetection(ObjectTyoe gameObjectTyoe1, ObjectTyoe gameObjectTyoe2, ActionOnCollision actionOnCollision)
        {
            this.GameObjectTyoe1 = gameObjectTyoe1;
            this.GameObjectTyoe2 = gameObjectTyoe2;
            this.ActionOnCollision1 = actionOnCollision;

        }

        public ActionOnCollision ActionOnCollision1 { get => ActionOnCollision; set => ActionOnCollision = value; }
        public static void DetectCollision(GameObject ob1, GameObject ob2, ActionOnCollision act, Game g)
        {
            if (ob1.GetPictureBox().Bounds.IntersectsWith(ob2.GetPictureBox().Bounds))
            {
                if (act == ActionOnCollision.Increasepoints)
                {

                    g.Addpoints(1);
                }
                else if (act == ActionOnCollision.Decreasepoints)
                {

                    g.Removepoints(1);
                }
                else if (act == ActionOnCollision.ChangeDirection)
                {
                    if (ob1.objectTyoe != ObjectTyoe.Player)
                    {
                        //ob1.Controller = changeDirection.GetNextMovement();
                    }
                }
                else
                {
                    MessageBox.Show("No Action");
                }
            }
        }
    }
}
