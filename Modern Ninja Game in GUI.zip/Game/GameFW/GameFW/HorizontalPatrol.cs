﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameFW
{
    public class HorizontalPatrol : IMovement
    {
        private int speed;
        private Point boundry;
        private DirectionChoice direction;
        private int offset = 90;
        public HorizontalPatrol(int speed, Point boundry, DirectionChoice direction)
        {
            this.speed = speed;
            this.boundry = boundry;
            this.direction = direction;
        }
        public Point move(Point location)
        {
            if((location.X + offset) >= boundry.X)
            {
                direction = DirectionChoice.left;
            }
            else if(location.X + speed <= 0)
            {  direction = DirectionChoice.Rigth; }
            if(direction == DirectionChoice.left) { location.X -= speed; }
            else { location.X += speed; }
            return location;
        }
    }
}
