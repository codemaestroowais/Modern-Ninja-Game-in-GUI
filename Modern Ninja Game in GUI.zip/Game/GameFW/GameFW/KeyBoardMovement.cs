﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EZInput;
namespace GameFW
{
    public class KeyBoardMovement : IMovement
    {
        private int speed;
        private System.Drawing.Point boundry;
        private int offset;
        public KeyBoardMovement(int speed, System.Drawing.Point boundry)
        {
            this.speed = speed;
            this.boundry = boundry;
            offset = 50;
        }
        public System.Drawing.Point move(System.Drawing.Point location)
        {
            if(EZInput.Keyboard.IsKeyPressed(Key.UpArrow))
            {
                if(location.Y + speed > 10)
                {
                    location.Y -= speed;
                }
            }
            if(EZInput.Keyboard.IsKeyPressed(Key.DownArrow))
            {
                if(location.Y + offset < boundry.Y)
                {
                    location.Y += speed;
                }
            }
            if(EZInput.Keyboard.IsKeyPressed(Key.LeftArrow))
            {
                if(location.X + speed > 10)
                {
                    location.X -= speed;
                }
            }
            if(EZInput.Keyboard.IsKeyPressed(Key.RightArrow))
            {
                if(location.X + offset < boundry.X)
                {
                    location.X += speed;
                }
            }
            return location;
        }
    }
}
