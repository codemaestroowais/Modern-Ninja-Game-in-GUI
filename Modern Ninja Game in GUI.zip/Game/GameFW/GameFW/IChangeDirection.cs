﻿using GameFW;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameFW
{
    public interface IChangeDirection
    {
        IMovement GetPresentMovement(int speed, Point Boundary, DirectionChoice directionChoice);
        IMovement GetNextMovement(int speed, Point Boundary, DirectionChoice directionChoice);
    }
}
