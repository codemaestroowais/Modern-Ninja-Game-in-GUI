﻿using GameFW;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameFW
{
    public class ChangeDirection : IChangeDirection
    {
        public IMovement GetNextMovement(int speed, Point Boundry, DirectionChoice directionChoice)
        {
            IMovement movement = new HorizontalPatrol(speed, Boundry, directionChoice);
            return movement;
        }


        public IMovement GetPresentMovement(int speed, Point Boundry, DirectionChoice directionChoice)
        {
            IMovement movement = new VerticalPatrol(speed, Boundry, directionChoice);
            return movement;
        }

    }
}
