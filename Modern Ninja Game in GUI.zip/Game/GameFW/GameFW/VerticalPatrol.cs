﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameFW
{
    public class VerticalPatrol : IMovement
    {
        private int speed;
        private Point boundry;
        private DirectionChoice direction;
        private int offset = 90;
        public VerticalPatrol(int speed, Point boundry, DirectionChoice direction)
        {
            this.speed = speed;
            this.boundry = boundry;
            this.direction = direction;
        }
        public Point move(Point location)
        {
            if((location.Y + offset) >= boundry.Y)
            {
                direction = DirectionChoice.Up;
            }
            else if(location.Y - speed <= 0)
            {
                direction = DirectionChoice.down;
            }
            if(direction == DirectionChoice.Up)
            {
                location.Y -= speed;
            }
            else
            {
                location.Y += speed;
            }
            return location;
        }
    }
}
