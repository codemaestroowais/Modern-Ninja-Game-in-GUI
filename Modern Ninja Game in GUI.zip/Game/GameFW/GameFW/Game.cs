﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace GameFW
{
    public class Game 
    {
        List<GameObject> gameObjectList;
        Form container;
        private static Game instance;
        List<CollisionDetection> CollisionDetections;
        private int GamePlayerCount = 0;
        private int GameEnemyCount = 0;
        private  int Points;
        private Game(Form container) 
        {
            gameObjectList = new List<GameObject>();
            CollisionDetections = new List<CollisionDetection>();
            this.container = container;
            Points = 0;
        }
        public static Game Instance(Form form)
        {
            if (instance == null)
            {
                instance = new Game(form);
                return instance;
            }
            return instance;
        }
        public void addGameObject(Image img, int left, int top, IMovement controller, ObjectTyoe objecttype)
        {
            //For Composition type of association
            GameObject gameObject = new GameObject(img, left, top, controller, objecttype);
            gameObjectList.Add(gameObject);
            container.Controls.Add(gameObject.GetPictureBox());
        }
        public void AddCollision(CollisionDetection collisionDetection)
        {
            CollisionDetections.Add(collisionDetection);

        }
        public void update(Game g)
        {
            foreach(GameObject gameObject in gameObjectList) 
            { 
                gameObject.update();
                if (gameObject.objectTyoe == ObjectTyoe.Player)
                {
                    GamePlayerCount++;
                }
                if (gameObject.objectTyoe == ObjectTyoe.Enemy)
                {
                    GameEnemyCount++;
                }
            }
            foreach (GameObject gameObject in gameObjectList)
            {
                if (gameObject.objectTyoe == ObjectTyoe.Player)
                {
                    foreach (GameObject gameObject1 in gameObjectList)
                    {
                        if (gameObject1.objectTyoe != ObjectTyoe.Player)
                        {
                            foreach (CollisionDetection collisionDetection in CollisionDetections)
                            {
                                if (collisionDetection.GameObjectTyoe1 == gameObject.objectTyoe && collisionDetection.GameObjectTyoe2 == gameObject1.objectTyoe)
                                {
                                    CollisionDetection.DetectCollision(gameObject, gameObject1, collisionDetection.ActionOnCollision, g);
                                }
                            }
                        }
                    }
                }
            }

        }
        public int GetPlayerCount()
        {
            return GamePlayerCount;
        }
        public int GetEnemyCount()
        {
            return GameEnemyCount;
        }
        public int GetPoints()
        {
            return Points;
        }
        public void Addpoints(int points)
        {
            Points += points;
        }
        public void Removepoints(int points)
        {
            Points -= points;
        }
    }
}
